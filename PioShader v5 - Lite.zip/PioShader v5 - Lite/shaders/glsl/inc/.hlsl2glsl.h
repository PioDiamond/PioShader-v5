
// Created by PioDiamond
// Please credit if you used this.
// IG : @PioDiamond
// Youtube : https://youtube.com/PioDiamond
precision highp float;

#define float2 vec2
#define float3 vec3
#define float4 vec4
#define float2x2 mat2
#define float3x3 mat3
#define mul( x, y ) ( x * y )
#define fmod mod
#define atan2 atan
#define lerp mix
#define frac fract
