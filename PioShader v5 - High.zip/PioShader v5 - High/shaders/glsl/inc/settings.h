// Created by PioDiamond
// IG : @PioDiamond
// Youtube : https://youtube.com/PioDiamond


// -- Sky
#define CLOUDS 1

// -- RenderChunk
#define LEAVES_WAVE 1
#define GRASS_WAVE 1
#define TORCH_COLOR 1
#define WATER_WAVES 1
#define CLOUDS_REFLECTION 1
#define SUN_REFLECTION 1
#define GRASS_SHADOW 1
#define BLOCK_SHADOW 1
#define DIRLIGHT 1
#define RAIN_SPLASH 1
#define CAUSTIC 1
