// Created by PioDiamond
// Please credit if you used this.
// IG : @PioDiamond
// Youtube : https://youtube.com/PioDiamond


  #define rotate(x) float2x2(cos( x ), -sin( x ), sin( x ), cos( x ))

// "Clouds" Created by PioDiamond
// ----------------------------------------------------------------------------------
float3 PioClouds( float2 p, data deteksi, int ulang );
float3 clouds( float2 p, data deteksi ) {
  const int ulang = 2;
  return PioClouds( p, deteksi, ulang );
}

float3 PioClouds( float2 p, data deteksi, int ulang ) {
  const float skala = 9.0;
  const float cepat = 0.03;
  float waktu = ( cepat * TIME );

    float2 uv;
    float2 pos;
    float clouds_;
    uv = pos = p * skala * vec2( 0.6, 1.0 ) + vec2( waktu, -waktu );
    float d = 1.0;
    float2x2 m = rotate( 90.0 );
    highp float cloud = noise( mul( m, pos ) );
    for( int i = 0; i < ulang; i++ ){
        pos *= 3.5;
        d *= 4.0;
        cloud += noise( mul( m, pos ) ) / d;
    }
    cloud = pow( cloud, 3.0 ) * -5.0 + 0.7;
    if( fogControl.x > 0.0 ){
      clouds_ = lerp( cloud, fogColor.b, deteksi.hujan );
    }
    else {
      clouds_ = cloud;
    }
    return clamp( float3( clouds_, clouds_, clouds_), 0.0, 1.0 );
}
// ----------------------------------------------------------------------------------
